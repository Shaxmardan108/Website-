window.onload=()=>{document.getElementById("loader").style.display="none";};

const toggle=document.getElementById("modeToggle");
toggle.onclick=()=>{document.body.classList.toggle("dark");};

let topBtn=document.getElementById("topBtn");
window.onscroll=()=>{
 if(document.documentElement.scrollTop>200){
  topBtn.style.display="block";
 }else{
  topBtn.style.display="none";
 }
};

topBtn.onclick=()=>window.scrollTo({top:0,behavior:"smooth"});
